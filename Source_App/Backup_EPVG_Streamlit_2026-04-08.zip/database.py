"""
Module de base de données SQLite pour les décisions des experts.
"""

import sqlite3
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Dict

DB_PATH = Path(__file__).parent / "decisions.sqlite"


def _get_connection() -> sqlite3.Connection:
    """Crée ou ouvre la base de données et initialise les tables."""
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS decisions_expert (
            instance_id TEXT PRIMARY KEY,
            nom_etablissement TEXT NOT NULL,
            decision TEXT NOT NULL,
            commentaire TEXT DEFAULT '',
            date_decision TEXT NOT NULL
        )
    """)
    conn.commit()
    return conn


def save_decision(instance_id: str, nom_etablissement: str, decision: str, commentaire: str):
    """Enregistre ou met à jour une décision d'expert."""
    conn = _get_connection()
    try:
        conn.execute("""
            INSERT INTO decisions_expert (instance_id, nom_etablissement, decision, commentaire, date_decision)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(instance_id) DO UPDATE SET
                decision = excluded.decision,
                commentaire = excluded.commentaire,
                date_decision = excluded.date_decision
        """, (instance_id, nom_etablissement, decision, commentaire, datetime.now().isoformat()))
        conn.commit()
    finally:
        conn.close()


def get_decision(instance_id: str) -> Optional[Dict]:
    """Récupère la décision existante pour un établissement."""
    conn = _get_connection()
    try:
        row = conn.execute(
            "SELECT * FROM decisions_expert WHERE instance_id = ?", (instance_id,)
        ).fetchone()
        if row:
            return dict(row)
        return None
    finally:
        conn.close()


def get_all_decisions() -> List[Dict]:
    """Récupère toutes les décisions enregistrées."""
    conn = _get_connection()
    try:
        rows = conn.execute("SELECT * FROM decisions_expert ORDER BY date_decision DESC").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()
