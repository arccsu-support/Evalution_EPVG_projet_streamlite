"""
Dashboard EPVG — Habilitation & Expertise
Application Streamlit pour le monitoring et l'aide à la décision
pour l'évaluation des établissements pharmaceutiques (EPVG) à Kinshasa.
"""

import os
import streamlit as st
import pandas as pd
import urllib.parse
import plotly.graph_objects as go
from io import BytesIO
from datetime import datetime
from dotenv import load_dotenv
from typing import Optional
import base64
import folium
from streamlit_folium import st_folium


# Load .env explicitly from the script's directory
env_path = os.path.join(os.path.dirname(__file__), '.env')
load_dotenv(env_path)
from odk_client import ODKClient, generate_demo_data
from database import save_decision, get_decision, get_all_decisions
from scoring import (
    SCORE_COLUMNS, RUBRIQUE_LABELS, PHOTO_FIELDS,
    CATEGORIES, DECISION_OPTIONS, categorize,
)

# Constantes d'authentification
APP_USER = os.getenv("APP_USER", "admin")
APP_PASSWORD = os.getenv("APP_PASSWORD", "admin")

# ── Configuration de la page ─────────────────────────────────────────────────
st.set_page_config(
    page_title="Dashboard EPVG — Habilitation",
    page_icon="🏥",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── CSS personnalisé ─────────────────────────────────────────────────────────
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

    /* ── Global ────────────────────────────────────────── */
    html, body, [class*="css"] {
        font-family: 'Inter', sans-serif;
    }
    .main .block-container {
        padding-top: 1.5rem;
        max-width: 1300px;
    }

    /* ── Header ────────────────────────────────────────── */
    .dashboard-header {
        background: linear-gradient(135deg, #0B2447 0%, #19376D 50%, #576CBC 100%);
        border-radius: 16px;
        padding: 2rem 2.5rem;
        margin-bottom: 1.8rem;
        color: white;
        box-shadow: 0 8px 32px rgba(11, 36, 71, 0.25);
    }
    .dashboard-header h1 {
        margin: 0;
        font-size: 1.9rem;
        font-weight: 800;
        letter-spacing: -0.5px;
    }
    .dashboard-header p {
        margin: 0.3rem 0 0 0;
        font-size: 0.95rem;
        opacity: 0.85;
    }

    /* ── KPI Cards ─────────────────────────────────────── */
    .kpi-card {
        background: white;
        border-radius: 14px;
        padding: 1.3rem 1.5rem;
        box-shadow: 0 2px 12px rgba(0,0,0,0.06);
        border-left: 5px solid;
        transition: transform 0.2s ease;
        height: 100%;
    }
    .kpi-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(0,0,0,0.1);
    }
    .kpi-value {
        font-size: 2rem;
        font-weight: 800;
        line-height: 1.1;
    }
    .kpi-label {
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: #64748b;
        font-weight: 600;
        margin-top: 0.3rem;
    }

    /* ── Score global card ─────────────────────────────── */
    .score-card {
        border-radius: 16px;
        padding: 1.8rem 2rem;
        text-align: center;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    }
    .score-card .score-value {
        font-size: 3.5rem;
        font-weight: 800;
        line-height: 1;
    }
    .score-card .score-label {
        font-size: 1rem;
        font-weight: 600;
        margin-top: 0.5rem;
    }

    /* ── Photo gallery ─────────────────────────────────── */
    .photo-card {
        background: #f8fafc;
        border-radius: 12px;
        padding: 0.8rem;
        text-align: center;
        border: 1px solid #e2e8f0;
        transition: all 0.2s ease;
        height: 100%;
        display: flex;
        flex-direction: column;
    }
    .photo-card:hover {
        border-color: #576CBC;
        box-shadow: 0 4px 16px rgba(0,0,0,0.08);
        transform: translateY(-2px);
    }
    
    /* Wrapper standardisé pour uniformiser la taille de toutes les photos */
    .photo-wrapper {
        width: 100%;
        height: 180px; 
        border-radius: 8px;
        overflow: hidden;
        margin-bottom: 0.5rem;
        background: #e2e8f0;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    /* Cibler les images Streamlit générées dans le wrapper */
    .photo-card img {
        width: 100% !important;
        height: 180px !important;
        object-fit: cover !important;
        border-radius: 8px !important;
    }

    .photo-label {
        font-size: 0.8rem;
        font-weight: 600;
        color: #334155;
        margin-top: auto;
        padding-top: 0.5rem;
        line-height: 1.2;
    }
    
    .photo-missing {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 180px;
        background: #f1f5f9;
        border-radius: 8px;
        color: #94a3b8;
        font-size: 0.85rem;
        width: 100%;
    }


    /* ── Decision form ─────────────────────────────────── */
    .decision-section {
        background: linear-gradient(135deg, #fefce8, #fef9c3);
        border-radius: 16px;
        padding: 1.5rem 2rem;
        border: 1px solid #fde047;
        margin-top: 1rem;
    }

    /* ── Sidebar styling ───────────────────────────────── */
    section[data-testid="stSidebar"] {
        background: linear-gradient(180deg, #0B2447 0%, #19376D 100%);
    }
    section[data-testid="stSidebar"] .stMarkdown,
    section[data-testid="stSidebar"] label,
    section[data-testid="stSidebar"] .stSelectbox label,
    section[data-testid="stSidebar"] .stRadio label {
        color: white !important;
    }

    /* ── Divider ───────────────────────────────────────── */
    .section-divider {
        border: none;
        height: 2px;
        background: linear-gradient(90deg, transparent, #cbd5e1, transparent);
        margin: 2rem 0;
    }
    
    /* ── Login Box ─────────────────────────────────────── */
    .login-container {
        max-width: 400px;
        margin: 5rem auto;
        padding: 2.5rem;
        background: white;
        border-radius: 16px;
        box-shadow: 0 10px 40px rgba(11, 36, 71, 0.1);
        text-align: center;
    }
    .login-container h2 {
        color: #0B2447;
        margin-bottom: 1.5rem;
        font-weight: 800;
    }
</style>
""", unsafe_allow_html=True)

# ── Header ────────────────────────────────────────────────────────────────────
from PIL import Image
import os

logo_path = os.path.join(os.path.dirname(__file__), "assets", "logo.png")
logo_img = None
if os.path.exists(logo_path):
    logo_img = Image.open(logo_path)

col1, col2 = st.columns([1, 4])
with col1:
    if logo_img:
        st.image(logo_img, use_container_width=True)
with col2:
    st.markdown("""
    <div class="dashboard-header">
        <h1>🏥 Dashboard EPVG — Habilitation & Expertise</h1>
        <p>Monitoring et aide à la décision • Évaluation des Établissements Pharmaceutiques • Kinshasa</p>
    </div>
    """, unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# AUTHENTIFICATION
# ══════════════════════════════════════════════════════════════════════════════
if "authenticated" not in st.session_state:
    st.session_state["authenticated"] = False

# Auto-correction si la session est dans un état incohérent (ex: ancienne session avec "admin")
if st.session_state["authenticated"] and "odk_server_url" not in st.session_state:
    st.session_state["authenticated"] = False
    st.rerun()

if not st.session_state["authenticated"]:
    st.markdown('<div class="login-container">', unsafe_allow_html=True)
    if logo_img:
        st.image(logo_img, width=150)
    st.markdown("<h2>🔒 Connexion à ODK Central</h2>", unsafe_allow_html=True)
    
    with st.form("login_form"):
        server_url = st.text_input("Serveur URL", value=os.getenv("ODK_SERVER_URL", "https://votre-serveur-odk.com"))
        email = st.text_input("Email ODK", value=os.getenv("ODK_EMAIL", ""))
        password = st.text_input("Mot de passe ODK", type="password")
        project_id = st.number_input("Project ID", value=int(os.getenv("ODK_PROJECT_ID", 1)), min_value=1)
        form_id = st.text_input("Form ID", value=os.getenv("ODK_FORM_ID", "Formulaire_evaluation_epvg_phase2"))
        
        submit_button = st.form_submit_button("Se Connecter", use_container_width=True)
        
        if submit_button:
            if server_url and email and password and form_id:
                # Test the connection to ensure it works before saving
                client_test = ODKClient(server_url, email, password, project_id, form_id)
                if client_test.authenticate():
                    st.session_state["authenticated"] = True
                    # Store these for later use in the sidebar
                    st.session_state["odk_server_url"] = server_url
                    st.session_state["odk_email"] = email
                    st.session_state["odk_password"] = password
                    st.session_state["odk_project_id"] = project_id
                    st.session_state["odk_form_id"] = form_id
                    st.session_state["odk_client"] = client_test  # Enregistrer le client ODK
                    st.rerun()
                else:
                    st.error("❌ Échec de la connexion. Vérifiez vos identifiants.")
            else:
                st.warning("⚠️ Veuillez remplir tous les champs.")
    st.markdown('</div>', unsafe_allow_html=True)
    st.stop()  # Stoppe l'exécution ici si non authentifié

# Initialisation par défaut pour éviter les NameError
df = pd.DataFrame()

# ══════════════════════════════════════════════════════════════════════════════
# SIDEBAR — CONFIGURATION
# ══════════════════════════════════════════════════════════════════════════════
load_dotenv()

with st.sidebar:
    if logo_img:
        st.image(logo_img, use_container_width=True)
    st.markdown("### ⚙️ Source de données")

    mode = st.radio(
        "Mode de connexion",
        ["🌐 ODK Central", "🧪 Données démo"],
        index=0,
        help="ODK Central : lecture des données réelles. Démo : données fictives.",
    )

    odk_client: Optional['ODKClient'] = None

    if mode == "🌐 ODK Central":
        st.markdown("---")
        # Récupération automatique du client ODK à partir de la session globale (de la page de connexion)
        if "authenticated" in st.session_state and st.session_state["authenticated"]:
             # Extract saved credentials from session state
             server_url = st.session_state.get("odk_server_url")
             email = st.session_state.get("odk_email")
             password = st.session_state.get("odk_password")
             project_id = st.session_state.get("odk_project_id")
             form_id = st.session_state.get("odk_form_id")

             if server_url and email and password:
                  if "odk_client" not in st.session_state:
                      auto_client = ODKClient(server_url, email, password, project_id, form_id)
                      with st.spinner("🔄 Connexion à ODK Central…"):
                          if auto_client.authenticate():
                              st.session_state["odk_client"] = auto_client
                              st.success("✅ Connecté automatiquement")
                          else:
                              st.error("❌ Échec de la connexion. Vérifiez vos identifiants.")
                              
             if "odk_client" in st.session_state:
                  odk_client = st.session_state["odk_client"]
                  st.caption("🟢 Connecté à ODK Central")
             
             if st.button("🔄 Rafraîchir la connexion", use_container_width=True):
                 st.cache_data.clear()
                 st.rerun()
            
    st.markdown("---")
    st.markdown("### 🧭 Navigation")
    
    page = st.radio(
        "Aller à la page :",
        ["📊 Statistiques Générales", "🏥 Évaluation Détaillée"],
        label_visibility="collapsed"
    )
    
    st.markdown("---")
    if st.button("🚪 Se Déconnecter", use_container_width=True):
        st.session_state["authenticated"] = False
        st.rerun()

# ══════════════════════════════════════════════════════════════════════════════
# CHARGEMENT DES DONNÉES
# ══════════════════════════════════════════════════════════════════════════════
@st.cache_data(ttl=300, show_spinner="📥 Chargement des données depuis ODK Central…")
def load_odk_data(_client: ODKClient) -> pd.DataFrame:
    return _client.get_submissions()


@st.cache_data(ttl=3600, show_spinner=False)
def load_labels_mapping(_client: ODKClient) -> dict:
    return _client.get_choices_mapping(["nom_etablissement", "nom_pharmacie"])

mapping_noms = {}

if mode == "🌐 ODK Central" and odk_client:
    df = load_odk_data(odk_client)
    mapping_noms = load_labels_mapping(odk_client)
elif mode == "🧪 Données démo":
    df = generate_demo_data()
else:
    st.info("⏳ En attente de connexion à ODK Central. Vérifiez vos paramètres dans la barre latérale.")
    st.stop()

if df.empty:
    st.warning("⚠️ Aucune donnée disponible. Vérifiez la connexion ODK ou passez en mode démo.")
    st.stop()

# ══════════════════════════════════════════════════════════════════════════════
# TRAITEMENT DES DONNÉES ET MAPPING DES COLONNES
# ══════════════════════════════════════════════════════════════════════════════
# Helper pour extraire une valeur de manière robuste (même si imbriquée dans des dicts ou avec préfixes)
def get_nested_val(data, target_key):
    target_key_lower = target_key.lower()
    
    # Cas 1: Si data est une Series (ligne Pandas aplatie ou non)
    if isinstance(data, pd.Series):
        # Recherche directe par suffixe dans les noms de colonnes
        for col in data.index:
            col_str = str(col).lower()
            if col_str == target_key_lower or any(col_str.endswith(f"{sep}{target_key_lower}") for sep in [".", "/", "-", "_"]):
                val = data[col]
                # Si la valeur est elle-même un dict (OData object), on extrait 'filename'
                if isinstance(val, dict) and "filename" in val:
                    return val["filename"]
                return val
        # Si non trouvé dans l'index direct, on cherche récursivement dans les valeurs qui sont des dicts
        for val in data.values:
            if isinstance(val, dict):
                res = get_nested_val(val, target_key)
                if res: return res
        return None

    # Cas 2: Si data est un dictionnaire
    if isinstance(data, dict):
        # Recherche directe
        if target_key in data: return data[target_key]
        for k, v in data.items():
            if k.lower() == target_key_lower: return v
            # Recherche récursive
            res = get_nested_val(v, target_key)
            if res: return res
    return None

# Mapping simple pour le filtrage
def find_col(df, target_name):
    target_name_lower = target_name.lower()
    for col in df.columns:
        col_str = str(col).lower()
        if col_str == target_name_lower or any(col_str.endswith(f"{sep}{target_name_lower}") for sep in [".", "/", "-", "_"]):
            return col
    return None

# Mapping automatique des colonnes vitales
col_total = find_col(df, "total")
col_nom = find_col(df, "nom_etablissement")
if not col_nom: col_nom = find_col(df, "nom_pharmacie") # Alternative possible

# Mapper les rubriques
rubrique_cols = {}
for r_code in SCORE_COLUMNS:
    found = find_col(df, r_code)
    if found:
        rubrique_cols[r_code] = found

if not col_total or not col_nom:
    st.error(f"❌ Erreurs de structure : Colonne 'total' ou 'nom_etablissement' non trouvée.")
    st.write("Colonnes détectées :", df.columns.tolist())
    st.info("💡 Si vous testez sans connexion réelle, passez en **Mode démo** dans la barre latérale.")
    st.stop()

# Nettoyage des scores
all_scores_to_clean = list(rubrique_cols.values()) + [col_total]
for col in all_scores_to_clean:
    df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

# Créer des colonnes standardisées pour l'app
df["total"] = df[col_total]
df["nom_etablissement"] = df[col_nom]

# Catégorisation
df["_categorie"] = df["total"].apply(lambda x: categorize(x)["category"])
df["_cat_label"] = df["total"].apply(lambda x: categorize(x)["label"])
df["_cat_emoji"] = df["total"].apply(lambda x: categorize(x)["emoji"])

# Instance ID détection robuste
# ODK Central REST API utilise l'ID de soumission (souvent stocké dans __id ou __system.submissionId en OData)
col_id = (
    find_col(df, "__id") or 
    find_col(df, "instanceID") or 
    find_col(df, "__system.submissionId") or
    find_col(df, "meta.instanceID")
)
if col_id:
    df["_instance_id"] = df[col_id]
else:
    df["_instance_id"] = df.index.astype(str)

def format_etablissement_name(nom):
    nom_str = str(nom)
    if nom_str in mapping_noms:
        return mapping_noms[nom_str]
    return nom_str.replace("_", " ").title()

# ══════════════════════════════════════════════════════════════════════════════
# GESTION DE LA VUE (ROUTING)
# ══════════════════════════════════════════════════════════════════════════════

if page == "📊 Statistiques Générales":
    # ══════════════════════════════════════════════════════════════════════════════
    # PAGE 1 : STATISTIQUES GLOBALES
    # ══════════════════════════════════════════════════════════════════════════════
    st.markdown("## 📊 Statistiques Macro-Évaluation EPVG")
    
    nb_total = len(df)
    moyenne = round(float(df["total"].mean()), 1)
    cat1_pct = round(float(len(df[df["_categorie"] == 1]) / nb_total * 100), 1) if nb_total else 0.0
    cat2_pct = round(float(len(df[df["_categorie"] == 2]) / nb_total * 100), 1) if nb_total else 0.0
    cat3_pct = round(float(len(df[df["_categorie"] == 3]) / nb_total * 100), 1) if nb_total else 0.0
    
    k1, k2, k3, k4, k5 = st.columns(5)
    
    with k1:
        st.markdown(f"""
        <div class="kpi-card" style="border-color: #576CBC;">
            <div class="kpi-value" style="color: #19376D;">{nb_total}</div>
            <div class="kpi-label">Établissements évalués</div>
        </div>
        """, unsafe_allow_html=True)
    
    with k2:
        avg_color = categorize(moyenne)["color"]
        st.markdown(f"""
        <div class="kpi-card" style="border-color: {avg_color};">
            <div class="kpi-value" style="color: {avg_color};">{moyenne}%</div>
            <div class="kpi-label">Moyenne générale</div>
        </div>
        """, unsafe_allow_html=True)
    
    with k3:
        st.markdown(f"""
        <div class="kpi-card" style="border-color: #E74C3C;">
            <div class="kpi-value" style="color: #E74C3C;">🔴 {cat1_pct}%</div>
            <div class="kpi-label">Non viables (&lt;50%)</div>
        </div>
        """, unsafe_allow_html=True)
    
    with k4:
        st.markdown(f"""
        <div class="kpi-card" style="border-color: #F39C12;">
            <div class="kpi-value" style="color: #F39C12;">🟠 {cat2_pct}%</div>
            <div class="kpi-label">Intermédiaires (50-70%)</div>
        </div>
        """, unsafe_allow_html=True)
    
    with k5:
        st.markdown(f"""
        <div class="kpi-card" style="border-color: #27AE60;">
            <div class="kpi-value" style="color: #27AE60;">🟢 {cat3_pct}%</div>
            <div class="kpi-label">Viables (≥70%)</div>
        </div>
        """, unsafe_allow_html=True)

    # ══════════════════════════════════════════════════════════════════════════════
    # CARTOGRAPHIE DES ÉTABLISSEMENTS
    # ══════════════════════════════════════════════════════════════════════════════
    st.markdown('<hr class="section-divider">', unsafe_allow_html=True)
    st.markdown("### 🗺️ Cartographie des Établissements")
    
    lat_col = find_col(df, "latitude") or find_col(df, "lat")
    lon_col = find_col(df, "longitude") or find_col(df, "lon") or find_col(df, "lng")
    
    if lat_col and lon_col:
        # Check if the coordinates are properly formatted to float
        df[lat_col] = pd.to_numeric(df[lat_col], errors="coerce")
        df[lon_col] = pd.to_numeric(df[lon_col], errors="coerce")
        df_map = df.dropna(subset=[lat_col, lon_col])
        
        if not df_map.empty:
            center_lat = float(df_map[lat_col].mean())
            center_lon = float(df_map[lon_col].mean())
            
            m = folium.Map(location=[center_lat, center_lon], zoom_start=11, tiles="cartodb positron")
            
            for idx, row in df_map.iterrows():
                cat_category = row.get("_categorie", 1)
                color = "green" if cat_category == 3 else "orange" if cat_category == 2 else "red"
                
                nom = str(row.get("nom_etablissement", "Inconnu"))
                nom_affiche = format_etablissement_name(nom)
                score = row.get("total", 0)
                label_cat = row.get("_cat_label", "")
                
                popup_html = f"""
                <div style="font-family: Arial, sans-serif; min-width: 200px;">
                    <h4 style="margin:0 0 5px 0; color:#19376D; font-size: 14px;">{nom_affiche}</h4>
                    <p style="margin:0; font-size: 13px;"><b>Score:</b> {score}%</p>
                    <p style="margin:0; font-size: 13px;"><b>Statut:</b> {label_cat}</p>
                </div>
                """
                
                folium.Marker(
                    location=[float(row[lat_col]), float(row[lon_col])],
                    popup=folium.Popup(popup_html, max_width=300),
                    tooltip=nom_affiche,
                    icon=folium.Icon(color=color, icon="plus", prefix="fa")
                ).add_to(m)
                
            st_folium(m, use_container_width=True, height=450, returned_objects=[])
        else:
            st.info("📌 Aucune coordonnée GPS valide trouvée pour ces établissements.")
    else:
        st.info("📌 Les données actuelles ne contiennent pas de coordonnées géographiques (latitude/longitude).")

    # Export
    st.markdown('<hr class="section-divider">', unsafe_allow_html=True)
    st.markdown("### 📥 Export & Hub de Données")

    export_col1, export_col2 = st.columns([2, 1])

    with export_col1:
        st.markdown("""
        Exportez un fichier Excel consolidé fusionnant les **scores ODK** et les **décisions expert**.
        Le rapport inclut toutes les rubriques, catégories et commentaires d'expert.
        """)
        
    with export_col2:
        if st.button("📥 Exporter le rapport final", use_container_width=True, type="primary"):
            # Préparer les données
            # Liste des colonnes de score réelles détectées
            real_score_cols = [c for c in rubrique_cols.values() if c in df.columns]
            export_df = df[["_instance_id", "nom_etablissement", "total"] + 
                           real_score_cols +
                           ["_cat_label"]].copy()

            # Appliquer les vrais noms pour l'export Excel
            export_df["nom_etablissement"] = export_df["nom_etablissement"].apply(format_etablissement_name)

            # Renommer les colonnes pour lisibilité
            rename_map = {
                "_instance_id": "Instance ID",
                "nom_etablissement": "Établissement",
                "total": "Score Total (%)",
                "_cat_label": "Catégorie",
            }
            # Inverser le mapping des rubriques pour l'audit
            for r_code, col_name in rubrique_cols.items():
                if str(col_name) in export_df.columns:
                    label = RUBRIQUE_LABELS.get(r_code)
                    if label:
                        rename_map[str(col_name)] = str(label)

            export_df.rename(columns=rename_map, inplace=True)

            # Fusionner les décisions
            all_decisions = get_all_decisions()
            if all_decisions:
                dec_df = pd.DataFrame(all_decisions)
                dec_df.rename(columns={
                    "instance_id": "Instance ID",
                    "decision": "Décision Expert",
                    "commentaire": "Commentaire Expert",
                    "date_decision": "Date Décision",
                }, inplace=True)
                dec_df.drop(columns=["nom_etablissement"], errors="ignore", inplace=True)
                export_df = export_df.merge(dec_df, on="Instance ID", how="left")

            # Générer le fichier Excel
            try:
                import openpyxl
                output = BytesIO()
                with pd.ExcelWriter(output, engine="openpyxl") as writer:
                    export_df.to_excel(writer, index=False, sheet_name="Résultats EPVG")

                    # Auto-ajuster les colonnes
                    worksheet = writer.sheets["Résultats EPVG"]
                    for column in worksheet.columns:
                        max_length = 0
                        col_letter = column[0].column_letter
                        for cell in column:
                            try:
                                if cell.value and len(str(cell.value)) > max_length:
                                    max_length = len(str(cell.value))
                            except (TypeError, ValueError):
                                pass
                        adjusted_width = min(int(max_length) + 2, 40)
                        worksheet.column_dimensions[col_letter].width = adjusted_width

                output.seek(0)
                timestamp = datetime.now().strftime("%Y%m%d_%H%M")
                st.download_button(
                    label="⬇️ Télécharger le fichier Excel",
                    data=output.getvalue(),
                    file_name=f"Rapport_EPVG_{timestamp}.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    use_container_width=True
                )
            except Exception as e:
                st.error(f"❌ Erreur lors de la génération de l'export Excel : {e}")

elif page == "🏥 Évaluation Détaillée":
    # ══════════════════════════════════════════════════════════════════════════════
    # PAGE 2 : VUE DÉTAILLÉE (ÉVALUATION)
    # ══════════════════════════════════════════════════════════════════════════════
    noms = sorted(df["nom_etablissement"].dropna().unique().tolist())

    # ── En-tête avec sélection sur la droite ──────────────────────────────────
    h_col1, h_col2 = st.columns([2, 1])
    
    with h_col2:
        selected_name = st.selectbox(
            "📍 Choisir un établissement", 
            noms, 
            index=0, 
            format_func=format_etablissement_name,
            label_visibility="collapsed"
        )
    
    # Calcul des données pour la ligne sélectionnée
    row = df[df["nom_etablissement"] == selected_name].iloc[0]
    instance_id = row["_instance_id"]
    score_total = row["total"]
    cat_info = categorize(score_total)

    with h_col1:
        st.markdown(f"## 🏥 {format_etablissement_name(selected_name)}")

    # --- Outils Diagnostic (déplacés dans Détails) ---
    if mode == "🌐 ODK Central":
        with st.expander("🛠️ Outils de Diagnostic & Expert Mode"):
            d_col1, d_col2 = st.columns(2)
            with d_col1:
                st.markdown("**Inspecteur JSON**")
                st.json(row.to_dict())
            with d_col2:
                st.markdown("**Vérification API ODK**")
                if not odk_client:
                    st.warning("⚠️ ODK Client non connecté. Connectez-vous dans le panneau latéral.")
                elif st.button("🔍 Tester l'accès aux photos", key="debug_odk_btn", use_container_width=True):
                    try:
                        import urllib.parse
                        api_id_encoded = urllib.parse.quote(str(instance_id))
                        url_base = f"{odk_client.server_url}/v1/projects/{odk_client.project_id}/forms/{odk_client.form_id}"
                        url_list = f"{url_base}/submissions/{api_id_encoded}/attachments"
                        r = odk_client.session.get(url_list, timeout=10)
                        if r.status_code == 200:
                            att_list = r.json()
                            st.success(f"✅ {len(att_list)} pièces jointes sur le serveur.")
                            names_in_server = [a['name'] for a in att_list]
                            comp_data = []
                            for f_key, f_label in PHOTO_FIELDS.items():
                                val = get_nested_val(row, f_key)
                                if val:
                                    status = "✅ Présent" if val in names_in_server else "❌ Absent"
                                    comp_data.append({"Photo": f_label, "Fichier": val, "État": status})
                            if comp_data: st.table(pd.DataFrame(comp_data))
                        else:
                            st.error(f"Erreur API {r.status_code}")
                    except Exception as e:
                        st.error(f"Erreur : {e}")

    # En-tête de la fiche (Score Card)
    st.markdown(f"""
    <div class="score-card" style="border-top: 5px solid {cat_info['color']};">
        <div class="score-value" style="color: {cat_info['color']};">{score_total}%</div>
        <div class="score-label">{cat_info['emoji']} {cat_info['label'].split(' ')[0]}</div>
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("### 📊 Performance par rubrique")
    rubriques = []
    scores = []
    colors = []
    
    for r_code, label in RUBRIQUE_LABELS.items():
        if r_code in rubrique_cols:
            col_name = rubrique_cols[r_code]
            if col_name in row and pd.notna(row[col_name]):
                score = float(row[col_name])
                rubriques.append(label)
                scores.append(score)
                colors.append(categorize(score)["color"])
    
    fig = go.Figure(go.Bar(
        x=scores,
        y=rubriques,
        orientation='h',
        marker_color=colors,
        text=[f"{s}%" for s in scores],
        textposition='auto',
    ))
    
    fig.update_layout(
        xaxis=dict(range=[0, 100], title_text="Score (%)"),
        yaxis=dict(autorange="reversed"),
        height=min(400, max(250, len(rubriques) * 40)),
        margin=dict(l=0, r=0, t=30, b=0),
        plot_bgcolor="white",
        font={"family": "Inter, sans-serif"}
    )
    fig.add_vline(x=50, line_dash="dash", line_color="#E74C3C", annotation_text="Seuil NV", annotation_position="top right", annotation={"font_color": "#E74C3C"})
    fig.add_vline(x=70, line_dash="dash", line_color="#27AE60", annotation_text="Seuil V", annotation_position="top left", annotation={"font_color": "#27AE60"})
    
    st.plotly_chart(fig, use_container_width=True)

    # Décision existante
    existing = get_decision(instance_id)
    if existing:
        dec_color = {"Retenu": "#27AE60", "À délibérer": "#F39C12", "Non viable": "#E74C3C"}.get(existing["decision"], "#64748b")
        st.markdown(f"""
        <div style="margin-top:1rem; padding:0.8rem 1rem; border-radius:10px; background:white; border:1px solid #e2e8f0;">
            <div style="font-size:0.75rem; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; font-weight:600;">Décision expert</div>
            <div style="font-size:1.1rem; font-weight:700; color:{dec_color}; margin-top:0.2rem;">{existing['decision']}</div>
            <div style="font-size:0.8rem; color:#475569; margin-top:0.3rem;">{existing.get('commentaire', '')}</div>
        </div>
        """, unsafe_allow_html=True)

    # ══════════════════════════════════════════════════════════════════════════════
    # GALERIE DE PHOTOS
    # ══════════════════════════════════════════════════════════════════════════════
    st.markdown('<hr class="section-divider">', unsafe_allow_html=True)
    st.markdown("### 📸 Galerie de preuves photographiques")
    
    # --- Debug zone pour les photos ---
    with st.expander("🔍 Diagnostic de la Galerie (Mapping OData)"):
        st.info("💡 L'application cherche maintenant les 19 champs de photos identifiés dans votre XLSForm.")
        
        api_instance_id = instance_id
        st.markdown(f"**ID de soumission utilisé (REST API) :** `{api_instance_id}`")
        
        mapping_debug = []
        for field, label in PHOTO_FIELDS.items():
            val = get_nested_val(row, field)
            status = "✅ Trouvé" if val else "❌ Vide"
            
            # Simuler l'URL pour dépanage
            debug_url = "-"
            if val and odk_client:
                safe_fname = str(val).strip()
                debug_url = f"{odk_client.server_url}/v1/projects/{odk_client.project_id}/forms/{odk_client.form_id}/submissions/{api_instance_id}/attachments/{safe_fname}"
                
            mapping_debug.append({
                "Photo": label,
                "ID XLS": field,
                "État": status,
                "Fichier": str(val) if val else "-",
                "URL API": debug_url
            })
        st.table(pd.DataFrame(mapping_debug))
    
    photo_cols = st.columns(4) # Passage à 4 colonnes pour 19 photos
    for idx, (field, label) in enumerate(PHOTO_FIELDS.items()):
        col_idx = idx % 4
        with photo_cols[col_idx]:
            # Utiliser la recherche robuste récursive
            filename = get_nested_val(row, field)

            # --- Rendu de la carte photo ---
            image_html = ""
            if filename and str(filename).strip() and str(filename).lower() not in ["nan", "none", ""]:
                fname = str(filename).strip()
                image_loaded = False
                
                if mode == "🌐 ODK Central" and odk_client:
                    img_data, img_err = odk_client.get_attachment_image(instance_id, fname)
                    if img_data:
                        try:
                            from PIL import Image
                            import io
                            img = Image.open(io.BytesIO(img_data.getvalue()))
                            
                            # Crop 16:9
                            w, h = img.size
                            target = 16/9
                            if w/h > target:
                                nw = int(target * h)
                                off = (w - nw) // 2
                                img = img.crop((off, 0, off + nw, h))
                            else:
                                nh = int(w / target)
                                off = (h - nh) // 2
                                img = img.crop((0, off, w, off + nh))
                            
                            # Conversion en base64 pour affichage HTML unique
                            buffered = io.BytesIO()
                            img.save(buffered, format="JPEG")
                            img_str = base64.b64encode(buffered.getvalue()).decode()
                            image_html = f'<img src="data:image/jpeg;base64,{img_str}">'
                            image_loaded = True
                        except:
                            image_html = '<div class="photo-missing">⚠️ Erreur Image</div>'
                    else:
                        image_html = f'<div class="photo-missing">❌ {str(img_err)[:20]}</div>'
                
                if not image_loaded:
                    if mode != "🌐 ODK Central":
                        image_html = f'<div class="photo-missing">📄<br><span style="font-size:0.6rem;">{fname}</span></div>'
                    # Si mode ODK et erreur, image_html contient déjà le message d'erreur
            else:
                image_html = '<div class="photo-missing">📷 Non fournie</div>'

            # Affichage en un seul bloc markdown pour éviter les duplications DOM liées aux widgets Streamlit
            st.markdown(f"""
                <div class="photo-card">
                    {image_html}
                    <div class="photo-label">{label}</div>
                </div>
            """, unsafe_allow_html=True)



    # ══════════════════════════════════════════════════════════════════════════════
    # MODULE DE DÉCISION EXPERT
    # ══════════════════════════════════════════════════════════════════════════════
    st.markdown('<hr class="section-divider">', unsafe_allow_html=True)
    st.markdown("### ⚖️ Décision du Jury / Comité")
    
    # Charger la décision existante
    saved_decision = get_decision(str(instance_id))
    
    if saved_decision:
        st.success(f"✅ Évaluation validée le {saved_decision['date_decision']}")
        c1, c2 = st.columns([1, 2])
        c1.metric("Statut Final", saved_decision['statut_expert'])
        c2.markdown(f"**Observations :**<br>{saved_decision['notes_expert']}", unsafe_allow_html=True)
        
        if st.button("📝 Modifier l'évaluation", key=f"edit_btn_{instance_id}"):
            # Pour relancer le process, on va utiliser la session_state
            st.session_state[f"edit_{instance_id}"] = True
            st.rerun()
            
    # Formulaire de décision (s'il n'y en a pas OU si on est en mode édition)
    if not saved_decision or st.session_state.get(f"edit_{instance_id}", False):
        st.markdown('<div class="decision-section">', unsafe_allow_html=True)
        with st.form(key=f"form_decision_{instance_id}"):
            dec_options = ["Viable", "Intermédiaire", "Non Viable", "Fermeture Imminente", "Mise en Demeure"]
            
            # Pré-sélection basées sur les anciennes données si existantes, sinon algo
            def_idx = 0
            if saved_decision and saved_decision['statut_expert'] in dec_options:
                def_idx = dec_options.index(saved_decision['statut_expert'])
            else:
                if cat_info["category"] == 1: def_idx = 2
                elif cat_info["category"] == 2: def_idx = 1
                elif cat_info["category"] == 3: def_idx = 0
                
            statut_expert = st.selectbox(
                "Statut officiel retenu par le comité :",
                options=dec_options,
                index=def_idx
            )
            
            def_notes = saved_decision['notes_expert'] if saved_decision else f"Conforme à l'évaluation algorithmique ({score_total}%)."
            notes_expert = st.text_area("Observations & Justifications :", value=def_notes, height=100)
            
            submit_decision = st.form_submit_button("💾 Valider la décision officielle", use_container_width=True)
            
            if submit_decision:
                success = save_decision(
                    instance_id=str(instance_id),
                    nom_etablissement=str(selected_name),
                    score_algo=float(score_total),
                    statut_expert=str(statut_expert),
                    notes_expert=str(notes_expert)
                )
                if success:
                    st.session_state[f"edit_{instance_id}"] = False # Fermer le mode édition
                    st.success("✅ Décision enregistrée dans la base Excel/SQLite.")
                    st.balloons()
                    st.rerun()
                else:
                    st.error("❌ Erreur lors de l'enregistrement.")
        st.markdown('</div>', unsafe_allow_html=True)

        st.markdown('</div>', unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# BOILERPLATE MÉTADONNÉES
# ══════════════════════════════════════════════════════════════════════════════
st.markdown("""
<div style="text-align: center; margin-top: 50px; font-size: 0.8rem; color: #94a3b8;">
    Système d'Évaluation des Pharmacies (EPVG) • Version 2.1<br>
    Développé avec Streamlit & ODK Central
</div>
""", unsafe_allow_html=True)
# ══════════════════════════════════════════════════════════════════════════════
# TABLEAU RÉCAPITULATIF (en sidebar)
# ══════════════════════════════════════════════════════════════════════════════
with st.sidebar:
    st.markdown("---")
    st.markdown("### 📋 Récapitulatif")

    # Mini tableau complet
    recap_df = df[["nom_etablissement", "total", "_cat_emoji"]].copy()
    recap_df.columns = ["Établissement", "Score", "Cat."]
    recap_df = recap_df.sort_values("Score", ascending=False)
    recap_df["Score"] = recap_df["Score"].apply(lambda x: f"{x:.0f}%")

    st.dataframe(recap_df, use_container_width=True, hide_index=True, height=350)

    # Stats décisions
    decisions = get_all_decisions()
    if decisions:
        st.markdown(f"**{len(decisions)}** décision(s) enregistrée(s)")
    else:
        st.caption("Aucune décision enregistrée")


# ── Footer ────────────────────────────────────────────────────────────────────
st.markdown('<hr class="section-divider">', unsafe_allow_html=True)
st.markdown("""
<div style="text-align:center; padding:1rem; color:#94a3b8; font-size:0.8rem;">
    Dashboard EPVG — Habilitation & Expertise • DIRCOP Kinshasa<br>
    Développé avec ❤️  en Python / Streamlit
</div>
""", unsafe_allow_html=True)
