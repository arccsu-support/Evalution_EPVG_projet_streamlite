"""
Logique de scoring et constantes de configuration pour le dashboard EPVG.
"""

# ── Rubriques de scores ──────────────────────────────────────────────────────
SCORE_COLUMNS = [
    "a_pourcentage", "b_pourcentage", "c_pourcentage",
    "d_pourcentage", "e_pourcentage", "f_pourcentage",
    "g_pourcentage", "h_pourcentage", "i_pourcentage",
]

RUBRIQUE_LABELS = {
    "a_pourcentage": "A – Personnel",
    "b_pourcentage": "B – Système Qualité",
    "c_pourcentage": "C – Installations / Locaux",
    "d_pourcentage": "D – Équipements",
    "e_pourcentage": "E – Organisation des stocks",
    "f_pourcentage": "F – Approvisionnement",
    "g_pourcentage": "G – Distribution / Transport",
    "h_pourcentage": "H – Auto-inspection",
    "i_pourcentage": "I – Autres",
}

# ── Mapping photos → libellés ────────────────────────────────────────────────
PHOTO_FIELDS = {
    "aa2": "Autorisation d'Ouverture",
    "ea2": "Image Bâtiments",
    "ea9": "Image Plafond",
    "ea13": "Zone de Quarantaine",
    "ea15": "Zone de Rebuts",
    "img_quai": "Quai de Déchargement",
    "img_cantine": "Cantine / Cafétéria",
    "img_salle_admin": "Salle d'Administration",
    "img_vestiaires": "Vestiaires",
    "img_installation": "Installations Sanitaires",
    "ec7": "Locaux d'Entreposage",
    "ec11": "Étagères",
    "ec15": "Stockage Produits",
    "ec22": "Protection Locaux (Nuisibles)",
    "ed4": "Thermomètre Fonctionnel",
    "ed6": "Thermomètre Étalonné",
    "eg4": "Hygromètre Fonctionnel",
    "eg6": "Thermomètre (Suivi)",
    "eh5": "Entretien Extincteurs",
}

# ── Catégorisation ───────────────────────────────────────────────────────────
CATEGORIES = {
    1: {"label": "Catégorie 1 – Non viable",  "color": "#E74C3C", "emoji": "🔴", "bg": "rgba(231,76,60,0.12)"},
    2: {"label": "Catégorie 2 – Intermédiaire","color": "#F39C12", "emoji": "🟠", "bg": "rgba(243,156,18,0.12)"},
    3: {"label": "Catégorie 3 – Viable",       "color": "#27AE60", "emoji": "🟢", "bg": "rgba(39,174,96,0.12)"},
}

DECISION_OPTIONS = ["Retenu", "À délibérer", "Non viable"]


def categorize(score: float) -> dict:
    """
    Retourne un dict avec la catégorie, le label, la couleur et l'emoji
    en fonction du score total (0-100).
    """
    if score < 50:
        cat = 1
    elif score < 70:
        cat = 2
    else:
        cat = 3
    return {"category": cat, **CATEGORIES[cat]}
